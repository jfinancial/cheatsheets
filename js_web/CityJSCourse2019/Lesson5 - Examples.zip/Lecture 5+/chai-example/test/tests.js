// var should = require('chai').should();
// var Multiply = require('../example.js');

// describe('Multiply tests', function(){
//     it('should return 2 if Multiplying 1 with 2', function(){
//         var mul1 = 1;
//         var mul2 = 2;
        
//         var expected = 2;
//         var actual = Multiply(mul1, mul2);
        
//         actual.should.equal(expected);
//     })
// })

// var chai = require('chai');
// var should = require('chai').should();
// var expect = chai.expect;
// var Multiply = require('../example.js');

// describe('Multiply tests', function(){
//     it('should return 2 if Multiplying 1 with 2', function(){
//         var mul1 = 1;
//         var mul2 = 2;
        
//         var expected = 2;
//         var actual = Multiply(mul1, mul2);

//         expect(actual).to.equal(expected);
//     })
// })


var chai = require('chai');
var should = require('chai').should();
var assert = chai.assert;
var Multiply = require('../example.js');

describe('Multiply tests', function(){
    it('should return 2 if Multiplying 1 with 2', function(){
        var mul1 = 1;
        var mul2 = 2;
        
        var expected = 2;
        var actual = Multiply(mul1, mul2);

       assert.equal(actual, expected, 'Message if it fails');
    })
})

