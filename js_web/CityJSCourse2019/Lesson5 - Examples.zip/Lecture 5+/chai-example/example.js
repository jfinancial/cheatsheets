module.exports = Multiply;

function Multiply(numberone,  numbertwo){
   return numberone*numbertwo;
}