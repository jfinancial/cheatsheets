var assert = require('assert');
var Multiply = require('../example.js');

describe('Multiply tests', function(){
    it('should return 2 if Multiplying 1 with 2', function(){
            assert.equal(Multiply(1,2), 2);
    })
})
