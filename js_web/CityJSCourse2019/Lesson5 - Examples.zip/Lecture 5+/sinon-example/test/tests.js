var chai = require('chai');
var should = chai.should();
var sinon = require('sinon');
var assert = require('assert');
var Email = require('../example.js');

describe('Sinon Tests', function(){
    // it('Sends Email', function(){
    //        var email1 = "aris@city.ac.uk";
    //        var email2 = "aristos.markogiannakis.1@city.ac.uk";

    //        var emailSpy = sinon.spy();
    //        Email(email1, email2, emailSpy);

    //        emailSpy.calledOnce.should.be.true;
    // })

    // it('Sends Email to both emails', function(){
    //     var email1 = "aris@city.ac.uk";
    //     var email2 = "aristos.markogiannakis.1@city.ac.uk";

    //     var emailSpy = sinon.spy();
    //     Email(email1, email2, emailSpy);

    //     emailSpy.calledWith(email1).should.be.true;

    // });

    it('Sends all emails', function(){
        var email1 = "aris@city.ac.uk";
        var email2 = "aristos.markogiannakis.1@city.ac.uk";

        var emailSpy = sinon.stub();
        var allEmailsSent  = Email(email1, email2, emailSpy);

        console.log(allEmailsSent);

        allEmailsSent.should.be.true;
    });
})
