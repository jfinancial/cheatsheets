module.exports = Email;

function Email(emailTo,  emailFrom, service){
    var sentTo = service();
    var sentFrom = service();
    console.log(sentTo);
    console.log(sentFrom);

    if (sentTo && sentFrom) {
      return true;
    }

    return false;
}