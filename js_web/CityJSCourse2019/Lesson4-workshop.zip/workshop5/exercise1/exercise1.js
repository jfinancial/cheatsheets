/* Syntax reminder:
myEl.addEventListener('click', function () {
    // Code goes here...
});
*/

// The elements to attach "click" handlers to
var docBody = document.body,
    parentElement = document.getElementById('parent'),
    childElement = document.getElementById('child');


// Add your listeners here...
