// The element to attach the listener to
var buttonWrapper = document.getElementById('button-wrapper');
